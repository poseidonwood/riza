<?php

	use PhpOffice\PhpSpreadsheet\Spreadsheet;
	use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
	
	class User extends User{

		public function excel()
		{
			$this->load->model('user_model');
			$spreadsheet = new Spreadsheet();
			$sheet = $spreadsheet->getActiveSheet();
			$sheet->setCellValue('A1', 'No');
			$sheet->setCellValue('B1', 'Nama');
			$sheet->setCellValue('C1', 'Email');
			$sheet->setCellValue('D1', 'Kelas');
			
			$siswa = $this->user_model->getAll();
			$no = 1;
			$x = 2;
			foreach($tb_user as $row)
			{
				$sheet->setCellValue('A'.$x, $no++);
				$sheet->setCellValue('B'.$x, $row->nama);
				$sheet->setCellValue('C'.$x, $row->Email);
				$sheet->setCellValue('D'.$x, $row->Kelas);
				$x++;
			}
			$writer = new Xlsx($spreadsheet);
			$filename = 'laporan_anggota';
			
			header('Content-Type: application/vnd.ms-excel');
			header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
			header('Cache-Control: max-age=0');
	
			$writer->save('php://output');
		}
	}
?>