<?php defined('BASEPATH') OR die('No direct script access allowed');

class User_model extends User {

     public function getAll()
     {
		  $tb_user = $this->db->get('tb_user')->result();
          return $tb_user;
     }

}