<?php

	$koneksi = new mysqli("localhost","root","","perpol");

	$filename = "rekap_anggota (".date('d-m-Y').").xls";

	header("content-disposition: attachment; filename=$filename");
	header("content-type: application/vdn.ms.excel");


?>

<h2>Laporan Anggota</h2>

<table border="1">
	<tr>
		<th>No</th>
		<th>NIS</th>
		<th>Nama</th>
        <th>Email</th>
        <th>Kelas</th>
     </tr>

     	<?php

        $no = 1;
		$sql = $koneksi->query("select * from tb_user");
		while ($data=$sql->fetch_assoc()) {
		$jk =($data['jk']);	
		?>
		<tr>
		<td><?php echo $no++ ; ?></td>
        <td><?php echo $data ["nis"]; ?></td>
        <td><?php echo $data ["nama_user"]; ?></td>
        <td><?php echo $data ["email_user"]; ?></td>
        <td><?php echo $data ["kelas"]; ?></td>
            
        </tr>

      <?php  } ?>

  </table>